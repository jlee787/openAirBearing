# Demo mode limits maximum number of solution points to a small number
DEMO_MODE = False
